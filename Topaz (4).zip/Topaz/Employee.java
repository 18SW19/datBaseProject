
package Topaz;


import javax.swing.*;
import java.awt.*;
import java.awt.Image;
import java.awt.event.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.io.File;
import java.sql.*;
import java.sql.Statement;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
;  
  
  
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Employee  // implements ActionListener
{
    String status=" ";
    Image img;
    Image photo;
    JFrame frame;
    JButton submit;
    JButton back;
     JButton picButton;
    JLabel  emp_details ;
    JLabel  picture ;
    JLabel firstname;
    JLabel lastname;
    JLabel gender;
    JLabel nic;
    JLabel email;
    JLabel age;
    JLabel qualification;
    JLabel material_status;
    JLabel contact_no;
    JLabel date_of_birth;
    JLabel domicile;
    JLabel image;
    JLabel pin_code;
    JLabel question_1;
    JLabel question_2;
   // JLabel background;
    JLabel serial;
    ButtonGroup group;
    byte [] attachPic = null;
       
    JTextField txt_fileName;
    JTextField textfirstname;
    JTextField textAge;
    JTextField textlastname;  
    JTextField textSerial;
    JTextField textNic;
    JTextField textContact;
    JPasswordField textCode;
    JTextField textEmail;
    JTextField textDate;
    JTextField textDomicile;
    JTextField textQualification;
    JRadioButton gender_button_male;
    JRadioButton gender_button_female;
    JRadioButton status_button_single;
    JRadioButton status_button_married;
    JRadioButton question1_button_yes;
    JRadioButton question1_button_no;
    JRadioButton question2_button_yes;
    JRadioButton question2_button_no;
    Font font;
    Font queFont;
    Font labelfont;
    int count=0;
    
              Employee(){
                  frame =new JFrame("Employee");
                  frame .setBounds(70 , 10 , 1100 , 700);
                  frame .setVisible(true);
                  frame .setLayout(null);
                 
                  Container con=frame.getContentPane();
                  con.setBackground(new java.awt.Color(60,171,99));
                  con.setLayout(null);
                 //
               
                 ImageIcon img=new ImageIcon("C:\\Users\\Zulnorain Abdani\\Documents\\NetBeansProjects\\Company\\src\\Topaz\\image (2).png"); 
                 image = new JLabel();
                 image.setBounds(900,15, 120,80);
                 image.setIcon(img);
                 image.setForeground(new java.awt.Color(0, 1, 0));
//                  background=new JLabel("" , JLabel.CENTER);
//                  background.setBounds(0 , 0 ,1400, 750);
//                  con.add(background);
                     
                 picture = new JLabel("");
                 picture.setBounds(710,5,130,100);
                 picture.setForeground(Color.WHITE);
                  
                 picButton = new JButton ("Attatch");
                 picButton.setBounds(730,154,80,25);
                 
                 txt_fileName = new JTextField();
                 txt_fileName.setBounds(680, 120,180,30);

                  
                  
                  font=new Font("Arial",Font.BOLD,40);
                  emp_details  = new JLabel ("Employee Details"); 
                  emp_details.setForeground(new java.awt.Color(255,255,255));
                  emp_details.setBounds(300,0,500,80);
                  emp_details .setFont(font);
                 
                  labelfont=new Font("Times New Roman ",Font.BOLD,20);
                //  labelfont.setForeground(new java.awt.Color(183,28, 28));
                  queFont =new Font("Arial",Font.BOLD,15);
                  
                  question_1 = new JLabel ("Are you an australian?");
                  question_1.setBounds(20,80,450,80);
                 // question_1.setForeground(new java.awt.Color(134,45,45));
                  question_1.setFont(queFont);
                  
                  question1_button_yes = new JRadioButton("yes");
                  question1_button_yes.setBounds(230,100,60,25);
                  //question1_button_yes .setForeground(new java.awt.Color(183,28, 28));
                  question1_button_yes.setFont(labelfont);
                  
                  question1_button_no = new JRadioButton("no");
                  question1_button_no.setBounds(310,100,50,25);
             //     question1_button_no.setForeground(new java.awt.Color(183,28, 28));
                  question1_button_no.setFont(labelfont);
                  
                  question_2 = new JLabel ("Do you have a working visa?");
               //   question_2 .setForeground(new java.awt.Color(183,28, 28));
                  question_2.setBounds(20,115,500,90);
                  question_2.setFont(queFont);
                  
                  question2_button_yes = new JRadioButton("yes");
                  question2_button_yes.setBounds(230,145,60,25);
          //        question2_button_yes .setForeground(new java.awt.Color(183,28, 28));
                  question2_button_yes.setFont(labelfont);
                  
                  question2_button_no = new JRadioButton("no");
                  question2_button_no.setBounds(310,145,50,25);
            //      question2_button_no.setForeground(new java.awt.Color(183,28, 28));
                  question2_button_no.setFont(labelfont);
                  
                
                  
                  firstname = new JLabel ("First Name");   
                  firstname.setBounds(80,180,150,80);
                  firstname.setFont(labelfont);
                  
                  textfirstname = new JTextField ();
                  textfirstname.setBounds(200,200,210,40);
                  textfirstname.setFont(labelfont);
                  
                  lastname = new JLabel ("Last Name");   
                  lastname.setBounds(80,250,150,80 );
                  lastname.setFont(labelfont);
                  
                  textlastname = new JTextField ();
                  textlastname.setBounds(200,270,210,40);
                  textlastname .setFont(labelfont);
                  
                  gender = new JLabel ("Gender");   
                  gender.setBounds(80,310,150,80);
                  gender.setFont(labelfont);
                  
                 gender_button_male = new JRadioButton("Male");
                 gender_button_male.setBounds(170,333,100,30);
                  gender_button_male.setFont(labelfont);
                  
                 gender_button_female = new JRadioButton("Female");
                 gender_button_female.setBounds(300,333,100,30);
                 gender_button_female.setFont(labelfont);
                  
                 nic = new JLabel ("CNIC NO");   
                 nic.setBounds(80,360,150,80);
                 nic.setFont(labelfont);
                 
                 textNic = new JTextField ();
                 textNic.setBounds(200,385,210,40);
                 textNic .setFont(labelfont);
                  
                 pin_code = new JLabel ("Pin Code");   
                 pin_code.setBounds(80,420,150,80);
                 pin_code.setFont(labelfont);
                 
                 
                 textCode = new JPasswordField ("");
                 textCode.setBounds(200,440,210,40);
                 textCode.setFont(labelfont);
                 
                 email = new JLabel ("Email");   
                 email.setBounds(80,480,150,80);
                 email.setFont(labelfont);
                 
                 textEmail = new JTextField ();
                 textEmail.setBounds(200,500,210,40);
                 textEmail.setFont(labelfont);
                  
                  serial =new JLabel("Serial no ");
                  serial.setBounds(10 , 20 , 100 , 20);
                  serial.setForeground(Color.BLACK);
                  serial.setFont(labelfont);
                  
                  textSerial =new JTextField();
                  textSerial.setBounds(100 , 20 , 40 , 20);
                  textSerial.setForeground(Color.BLACK);
                  textSerial.setFont(labelfont);
                  
                  age = new JLabel ("Age");   
                  age.setBounds(500,180,100,80);
                  age.setFont(labelfont);
                  
                  textAge = new JTextField ();
                  textAge.setBounds(650,200,210,40);
                  textAge.setFont(labelfont);
                  
                  qualification = new JLabel ("Qualification");   
                  qualification.setBounds(500,260,250,40);
                  qualification.setFont(labelfont);
                  
                 textQualification= new JTextField ();
                 textQualification.setBounds(650,270,210,40);
                 textQualification.setFont(labelfont);
                   
                 material_status = new JLabel ("Marital status");   
                 material_status.setBounds(500,315,150,40);
                 material_status.setFont(labelfont);
                   
                 status_button_single = new JRadioButton("Single");
                 status_button_single.setBounds(660,320,100,30);
                 status_button_single.setFont(labelfont);
                 
                    
                 status_button_married = new JRadioButton("Married");
                 status_button_married.setBounds(770,320,100,30);
                 status_button_married.setFont(labelfont);
                 
                 status_button_single.addActionListener(new ActionListener ()
                         {
                             public void actionPerformed(ActionEvent e)
                             {
                                 if( status_button_single.isSelected())
                                 {
                                     status_button_married.setSelected(false);
                                 }
                             }
                         });
               
                 
                  status_button_married.addActionListener(new ActionListener ()
                         {
                             public void actionPerformed(ActionEvent e)
                             {
                                 if( status_button_married.isSelected())
                                 {
                                     status_button_single.setSelected(false);
                                 }
                             }
                         });
                 
                 contact_no = new JLabel ("Contact No");   
                 contact_no.setBounds(500,360,150,80);
                 contact_no.setFont(labelfont);
                 
                 textContact = new JTextField ();
                 textContact.setBounds(650,385,210,40);
                 textContact.setFont(labelfont);
                 
                 
                 date_of_birth = new JLabel ("Date of birth");   
                 date_of_birth.setBounds(500,420,150,80);
                 date_of_birth.setFont(labelfont);
                 
                 
                 textDate = new JTextField ();
                 textDate.setBounds(650,440,210,40);
                 textDate.setFont(labelfont); 
                 
                 domicile = new JLabel ("Domicile");   
                 domicile.setBounds(500,480,150,80);
                 domicile.setFont(labelfont);
                 
                 textDomicile = new JTextField ();
                 textDomicile.setBounds(650,500,210,40);
                 textDomicile.setFont(labelfont);
                 
                 submit = new JButton ("Submit");   
                 submit.setBounds(400,590,100,40);
                 submit.setFont(labelfont);
                 
                 back = new JButton ("Back");   
                 back.setBounds(290,590,100,40);
                 back.setFont(labelfont);
                  
                   con .add(emp_details );
                   con .add(firstname);
                   con .add(textfirstname);
                   con.add(lastname);
                   con.add(textlastname);
                   con.add(serial);
                   con .add(textSerial);
                   con.add(gender);
                   con .add(gender_button_male);
                   con.add(gender_button_female);
                   con.add(nic);
                   con .add(textNic);
                   con.add(email);
                   con .add(textEmail);
                   con.add(material_status); 
                   con.add(status_button_single);
                   con .add(status_button_married);
                   con.add(picture);
                   con.add(age);
                   con.add( image);
                   con .add(textAge);
                   con.add(pin_code);
                   con .add(textCode);
                   con.add(qualification);
                   con .add(textQualification);
                   con.add(contact_no);
                   con.add(textContact);
                   con.add( date_of_birth);
                   con.add(textDate);
                   con.add(domicile);
                   con .add(submit);
                   con .add(back);
                   con .add( txt_fileName);
                   con .add(picButton);
                   con .add(textDomicile);
                   con .add(question_1);
                   con .add(question1_button_no);
                   con .add(question1_button_yes);
                   con .add(question_2);
                   con .add(question2_button_no);
                   con .add(question2_button_yes);
                  
            textAge.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
            String value = textAge.getText();
            int l = value.length();
            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9' ||  (ke.getKeyChar()== KeyEvent.VK_BACK_SPACE)
                    || (ke.getKeyChar()== KeyEvent.VK_DELETE )) {
               textAge.setEditable(true);
          
            } else {
               textAge.setEditable(false);
            
            }
         }
      });
                  
                  
            textContact.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
            String value = textContact.getText();
            int l = value.length();
            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9' ||  (ke.getKeyChar()== KeyEvent.VK_BACK_SPACE)
                    || (ke.getKeyChar()== KeyEvent.VK_DELETE )) {
               textContact.setEditable(true);
          
            } else {
               textContact.setEditable(false);
            
            }
         }
      });
             textfirstname.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
            String value =  textfirstname.getText();
           // int l = value.length();
            if (Character.isLetter(ke.getKeyChar()) || Character.isWhitespace (ke.getKeyChar()) || 
                    Character.isISOControl(ke.getKeyChar()) ) {
               textfirstname.setEditable(true);
          
            } else {
                textfirstname.setEditable(false);
            
            }
         }
      });
             
            textlastname.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
            String value =  textlastname.getText();
           // int l = value.length();
            if (Character.isLetter(ke.getKeyChar()) || Character.isWhitespace (ke.getKeyChar()) || 
                    Character.isISOControl(ke.getKeyChar()) ) {
               textlastname.setEditable(true);
          
            } else {
                textlastname.setEditable(false);
            
            }
         }
      });
               
            textDomicile.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
            String value =  textDomicile.getText();
           // int l = value.length();
           if (Character.isLetter(ke.getKeyChar()) || Character.isWhitespace (ke.getKeyChar()) || 
                    Character.isISOControl(ke.getKeyChar()) )  {
               textDomicile.setEditable(true);
          
            } else {
                textDomicile.setEditable(false);
            
            }
         }
      });
                    
            textCode.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
            String value = textCode.getText();
            int l = value.length();
            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9' ||  (ke.getKeyChar()== KeyEvent.VK_BACK_SPACE)
            || (ke.getKeyChar()== KeyEvent.VK_DELETE )) {
              textCode.setEditable(true);
          
            } else {
               textCode.setEditable(false);
            
            }
         }
      }); 
            
            textNic.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
            String value = textNic.getText();
            int l = value.length();
            if (ke.getKeyChar() >= '0' && ke.getKeyChar() <= '9' ||  (ke.getKeyChar()== KeyEvent.VK_BACK_SPACE)
            || (ke.getKeyChar()== KeyEvent.VK_DELETE )) {
              textNic.setEditable(true);
          
            } else {
               textNic.setEditable(false);
            
            }
         }
      }); 
         
            textQualification.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent ke) {
            String value =  textQualification.getText();
           // int l = value.length();
            if (Character.isLetter(ke.getKeyChar()) || Character.isWhitespace (ke.getKeyChar()) || 
                    Character.isISOControl(ke.getKeyChar()) ) {
               textQualification.setEditable(true);
          
            } else {
                textQualification.setEditable(false);
            
            }
         }
      });
                  
                
                picButton.addActionListener(new ActionListener(){

                      public void actionPerformed(ActionEvent ae) {
            
                          JFileChooser chooser = new JFileChooser();
                          chooser.showOpenDialog(null);
                          File f = chooser.getSelectedFile();
                            
                         String  fileName = f.getAbsolutePath();
                                     
                                       
                          txt_fileName.setText(fileName);
                          Image getAbsolutePath = null;
                          ImageIcon Icon = new ImageIcon (fileName);
                          Image image = Icon.getImage().getScaledInstance(picture.getWidth(), picture.getHeight(), 
                                  Image.SCALE_SMOOTH);
                          picture.setIcon(Icon);
                          
                          
                       
                      }
                      
                });
                
                
                  
                back.addActionListener(new ActionListener(){

                      public void actionPerformed(ActionEvent ae) {
                      
                      
                      }});
                
                         
                submit.addActionListener(new ActionListener(){

                      public void actionPerformed(ActionEvent ae) {
                          
                     try{
                         
                         String image = txt_fileName.getText();
                         image= image.replace("\\", "\\\\");
                        // Image modified_image = image.getScaledInstance(500,500 , java.awt.Image.SCALE_SMOOTH);
                     // String EMAIL_PATTERN = " ^[\\w!#$%&amp;’*+/=?`{|}~^-]+(?:\\.[\\w!#$%&amp;’*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
//Pattern pattern;
//Matcher matcher;
//matcher = pattern.matcher(o.toString());
//if(!matcher.matches())
//{        
//      throw new ValidatorException("");
//}
                           
                          //String email_pattern = "^[a-zA-Z0-9]+@(1)+[a-zA-Z0-9]+[.](1)+[a-zA-Z0-9]";
//                          
                            String EMAIL_PATTERN = "^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$";

                            Pattern pattern = Pattern.compile(EMAIL_PATTERN,Pattern.CASE_INSENSITIVE);
                          Matcher regexMatcher = pattern.matcher(textEmail.getText().toString());
                          if(!regexMatcher.matches())
                          {
                           JOptionPane.showMessageDialog(null, "Email is not correct.");
                       }
                         
                              String url="jdbc:oracle:thin:@localhost:1521:orcl";
                              Class.forName("oracle.jdbc.driver.OracleDriver");
                               System.out.println("Driver loaded");

                              Connection con=DriverManager.getConnection(url ,"scott" , "scott");
                             
                              
                              Statement st=con.createStatement();
                           String q="insert into Employee (Serial_NO,FIRST_NAME,LAST_NAME,GENDER,CNIC_NO,EMAIL,"
                                   + "AGE,QUALIFICATION,MARITAL_STATUS,CONTACT_NO,\n" +
                                    "DATE_OF_BIRTH,DOMICILE,IS_AUSTRALIAN,WORKING_VISA)"
                                   + " VALUES(? , ?, ?, ? , ? , ? , ? , ?, ?, ?, ?, ?, ?, ?)";
                                   
//                                   String q="insert into  (TESTNAME)"
//                                      + "values(?)";
                              PreparedStatement pr=con.prepareStatement(q);
//                              
//                                     private static int currentNumber=3000;
//                                     public static String GetNextNumber()
//                                  {
//                                       currentNumber++;
//                                       return "B"+currentNumber;
//                                  }

                              System.out.println("text serial "+textSerial.getText());
                              pr.setString(1 , textSerial.getText());
                              System.out.println("fname "+textfirstname.getText());
                              pr.setString(2, textfirstname.getText());
                              System.out.println("lname "+textlastname.getText());
                              pr.setString(3 , textlastname.getText());
                              String genderC=" ";
                              if(gender_button_male.isSelected())
                              {
                                   genderC="male";
                              }
                              else
                              {
                                  genderC="female";
                              }
                             
                              
                              System.out.println("gender "+genderC);
                              pr.setString(4 , genderC);
                              System.out.println("cnic "+textNic.getText());
                              pr.setString(5 ,  textNic.getText());
                              System.out.println("email "+textEmail.getText());
                              pr.setString(6 , textEmail .getText());
                              System.out.println("age "+textAge.getText());
                              pr.setString(7 , textAge.getText());
                              System.out.println("qualification "+textQualification.getText());
                              pr.setString(8 , textQualification.getText());
                              
                             
//                              public void JRadioButtonActionPerformed(ActionEvent e)
//                              {
                                  
                              
                              if(status_button_single.isSelected())
                              {
                                  status="married ";
                              }
                              else
                              {
                                  status="single";
                              }
                              
                              System.out.println("status "+status); 
                              
                               pr.setString(9 , status);
                             System.out.println("contact "+textContact.getText());
                               pr.setString(10 , textContact.getText());
                               System.out.println("date "+textDate.getText());
                              pr.setString(11 , textDate.getText());
                              System.out.println("domicile "+textDomicile.getText());
                              pr.setString(12 , textDomicile.getText());
                              String ques="";
                              if(question1_button_no.isSelected())
                              {
                                  ques="yes";
                              }else
                              {
                                   ques="no";
                              }
                              System.out.println("q1 "+ques);
                              pr.setString(13 , ques);
                              String ques1="";
                              if(question2_button_no.isSelected())
                              {
                                  ques1="no";
                              }
                              else
                              {
                                 ques1="yes";
                              }
                              System.out.println("q2 "+ques1);    
                              pr.setString(14 ,ques1);
                              
                              pr.executeQuery();
                                     
                              
                               JOptionPane.showMessageDialog(null, "Your form is succesfully submitted.");
                          
                      }   catch(SQLException | ClassNotFoundException ex){
                              Logger.getLogger(Employee.class.getName()).log(Level.SEVERE, null, ex);
                          }
                     new Email(textEmail.getText());
                            
                       //  sendMail("jannatfatima861@gmail.com",textEmail.getText(),"This is a dummy msg");
                      }
                      
                      
                      
                      
                      
                  });
//                          

              }

    void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}






