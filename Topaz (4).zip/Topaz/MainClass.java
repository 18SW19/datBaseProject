
package Topaz;

      
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import javax.swing.*;
     

public class MainClass    {
    
     static JFrame frame;
      static Container con = null;
      
             static  JFrame imageframe;
             static  JCheckBox checkbox1;
             static  JCheckBox checkbox2;
             static  JCheckBox checkbox3;
                  
             static  JLabel background;
             static  JLabel note;
             static  JLabel reqNote;
             static  JTextArea capabilities;
            
             static JButton go;
             static JButton back;
             static JButton start;
                 
             static JLabel documents ;
             static Font font;
             static Font fontdoc;
                  
      
    public static void main(String args [])
    { 
                    
                  //frame.setForeground(Color.BLUE);
                  
                  font=new Font("Times New Roman ",Font.BOLD,20);
                  note = new JLabel ("Eligibility criteria ");
                  note.setForeground(new java.awt.Color(255,255,255));
                  note.setBounds(130,15,200,30);
                  note.setFont(font);
                  
                  capabilities = new JTextArea ("Minimun BE in software engineering bearing experties\n"
                          + "in following mentioned languages and operating systems and softwares.\n."
                          + "C++\n"+"Java\n "+"Labview \n "+" Ios \n "+"Windows \n "+"Android \n "+"Web-desining \n "
                          + "Digital marketing\n"+"Free lancing\n "+"Matlab.");
                  capabilities.setBounds(10,50,500,200);
                  fontdoc=new Font("Times New Roman ",Font.BOLD,15);
                  documents = new JLabel ("Documents required :");
                  documents .setForeground(new java.awt.Color(255,255,255));
                  documents.setBounds(25,260,200,30);
                  documents.setFont(fontdoc);
                  
                  go = new JButton ( "GO ");
                  go.setBounds(450,460,80,30);
                  go.setFont(fontdoc);

                  
                 
                  go.addActionListener(new ActionListener()                   
                        {
                        public void actionPerformed(ActionEvent e )
                        {
                            int i =0;
                            if( checkbox1.isSelected()==true &&   checkbox2.isSelected()==true
                                    &&  checkbox3.isSelected()==true  ){

                            new Employee();
                            }
                            else
                            {
                               JOptionPane.showMessageDialog(null, "Please select all the requirements.");
                            }
                        }

                     
                        
                        
                                
                    });
                    
                 	
             
                ImageIcon img=new ImageIcon("C:\\Users\\Zulnorain Abdani\\Documents\\NetBeansProjects\\Company\\src\\Topaz\\logo.png");
                ImageIcon img1=new ImageIcon("C:\\Users\\Zulnorain Abdani\\Documents\\NetBeansProjects\\Company\\src\\Topaz\\start (2).png");
                 
                
                background=new JLabel();
                background.setBounds(0 , 0 ,1400, 750);
                background.setIcon(img);
                     
                imageframe =new JFrame();
                imageframe .setBounds(0 , 0 , 1400 , 750);
                imageframe .setVisible(true);
                imageframe.setLayout(null);
                start = new JButton("");
                start.setBounds(1160,650,170,54);
                start.setBorder(null);
                start.setIcon(img1);
                start.setBackground(new java.awt.Color(0,0,0));
                imageframe.add(start);
                imageframe.add( background);  
                 
//                 
                     
                 
                         
                start.addActionListener(new ActionListener(){
 
                public void actionPerformed(ActionEvent ae) {
                          
                          
                             
                  frame =new JFrame("Requirements");
                  frame .setBounds(250 , 60 , 600 , 600);
                  frame .setVisible(true);
                  frame .setLayout(null);

                  con=frame.getContentPane();
                  con.setBackground(new java.awt.Color(45,130,75));
                  con.setLayout(null);
                  
                  
                  
                  checkbox1 = new JCheckBox ("   CV   ");
                  checkbox1.setBounds(25,300,70,20);
                  checkbox1.setFont(fontdoc);
                  
                  checkbox2 = new JCheckBox ("   Domicile   ");
                  checkbox2.setBounds(25,330,120,20);
                  checkbox2.setFont(fontdoc);
                  
                   checkbox3 = new JCheckBox ("   Educational Certificates  ");
                  checkbox3.setBounds(25,370,220,20);
                  checkbox3.setFont(fontdoc);
                  
                  reqNote =  new JLabel ("Please fulfill these requirements.");
                  reqNote.setForeground(new java.awt.Color(255,255,255));
                  reqNote.setBounds(25,400,250,30);
                  reqNote.setFont(fontdoc);
                  
                 
                   
                  

                 con.add(note);
                 con.add(go);
               //  con.add(back);
                 con.add(capabilities);
                 con.add(reqNote);
                 con.add(checkbox1);
                 con.add(checkbox2);
                 con.add(checkbox3);
                 con.add(documents);
                                   
                      
                      }});
                
                 imageframe.setVisible(true);
       
}


   
}

